﻿#include <iostream>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

using namespace cv;
using namespace std;

void FilteredObject(Mat& threshold, Mat& cameraFeed, Scalar& colors, string& display) // tìm và vẽ viền
{
    Mat erode_element = getStructuringElement(MORPH_RECT, cv::Size(4, 4));
    Mat dilate_element = getStructuringElement(MORPH_RECT, cv::Size(8, 8));
    erode(threshold, threshold, erode_element);
    erode(threshold, threshold, erode_element);
    //imshow("Erode", inrImg);
    dilate(threshold, threshold, dilate_element);
    dilate(threshold, threshold, dilate_element);
    //dilate(inrImg, inrImg, dilate_element);
    vector< vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
    //use moments method to find our filtered object
    bool objectFound = false;
    if (hierarchy.size() > 0) {
        int numObjects = hierarchy.size();
        //if number of objects greater than MAX_NUM_OBJECTS we have a noisy filter
        if (numObjects < 1000)
         {
            for (int index = 0; index >= 0; index = hierarchy[index][0]) {

                Moments moment = moments((cv::Mat)contours[index]);

                double dM01 = moment.m01;
                double dM10 = moment.m10;
                double dArea = moment.m00;

                if (dArea > 10000) {

                    int posX = dM10 / dArea;
                    int posY = dM01 / dArea;
                    drawContours(cameraFeed, contours, -1, colors, 1.8);
                    putText(cameraFeed, display, Point(posX, posY + 20), 1, 1, Scalar(0,0,0), 2);
                }
                else objectFound = false;
            }

        }

        else putText(cameraFeed, "TOO MUCH NOISE! ADJUST FILTER", Point(0, 50), 1, 2, Scalar(0, 0, 255), 2);
    }
}

void CircleObject(Mat& threshold, Mat& cameraFeed, Scalar& colors)// tìm đường tròn
{
        std::vector<cv::Vec3f> circles;
        HoughCircles(threshold, circles, cv::HOUGH_GRADIENT, 1.5, threshold.rows, 100, 50, 50, 300);  // algorithm for detecting circles		

        for (int i = 0; i < circles.size(); i++) {
            std::cout << "Ball position X = " << circles[i][0] << ",\tY = " << circles[i][1] << ",\tRadius = " << circles[i][2] << "\n";
            cv::circle(cameraFeed, cv::Point((int)circles[i][0], (int)circles[i][1]), 3, colors, cv::FILLED);
            cv::circle(cameraFeed, cv::Point((int)circles[i][0], (int)circles[i][1]), (int)circles[i][2], colors, 2);
  putText(cameraFeed, "Detection Circle", cv::Point(20, 20), 1, 1, colors, 2);
  putText(cameraFeed, "0" + std::to_string(i + 1) + "(" + std::to_string((int)circles[i][0]) + "," + std::to_string((int)circles[i][1]) + ")", cv::Point(circles[i][0] - 5, circles[i][1] - 20), 1, 1, colors, 2);
  putText(cameraFeed, "R=" + std::to_string((int)circles[i][2]), cv::Point(circles[i][0], circles[i][1] - 35), 1, 1, colors, 2); 
    }
}

void imageWrite(const cv::Mat& image, const std::string filename)
{
    // Support for writing JPG
    vector<int> compression_params;
    compression_params.push_back(IMWRITE_JPEG_QUALITY);
    compression_params.push_back(100);

    // This writes to the specified path
    std::string path = "F:\\final\\" + filename + ".jpg";

    cv::imwrite(path, image, compression_params);
}
int main(int argc, char** argv)
{
    VideoCapture cap;
    cap.open(0); //capture the video from webcam
  //  "http://192.168.1.6:4747/video"

    if (!cap.isOpened())  // if not success, exit program
    {
        cout << "Cannot open the web cam" << endl;
        return -1;
    }

    int dem = 0;

    int iLowH = 160;
    int iHighH = 179;

    int iLowS = 150;
    int iHighS = 255;

    int iLowV = 60;
    int iHighV = 255;
    // Gam màu HSV của mà đỏ
    int iLowH_R = 160;
    int iHighH_R = 179;

    int iLowS_R = 150;
    int iHighS_R = 255;

    int iLowV_R = 60;
    int iHighV_R = 255;

    int iLowH_O = 0;
    int iHighH_O = 22;

    int iLowS_O = 150;
    int iHighS_O = 255;

    int iLowV_O = 60;
    int iHighV_O = 255;

    int iLowH_G = 38;
    int iHighH_G = 75;

    int iLowS_G = 150;
    int iHighS_G = 255;

    int iLowV_G = 60;
    int iHighV_G = 255;

    int iLowH_Y = 22;
    int iHighH_Y = 38;

    int iLowS_Y = 150;
    int iHighS_Y = 255;

    int iLowV_Y = 60;
    int iHighV_Y = 255;
    namedWindow("Control", WINDOW_AUTOSIZE); //create a window called "Control"
    createTrackbar("LowH", "Control", &iLowH, 179); //Hue (0 - 179)
    createTrackbar("HighH", "Control", &iHighH, 179);

    createTrackbar("LowS", "Control", &iLowS, 255); //Saturation (0 - 255)
    createTrackbar("HighS", "Control", &iHighS, 255);

    createTrackbar("LowV", "Control", &iLowV, 255);//Value (0 - 255)
    createTrackbar("HighV", "Control", &iHighV, 255);


    //Capture a temporary image from the camera
   // Mat imgTmp;
   // cap.read(imgTmp);

    //Create a black image with the size as the camera output
   // Mat imgLines = Mat::zeros(imgTmp.size(), CV_8UC3);;
    Mat imgOriginal;
    char key;

    while (true)
    {
        Mat frame;
        cap.retrieve(frame);
        bool success = cap.read(frame);
        if (!success) {
            cout << "Could not read from video file" << endl;
            return 1;
        }
        Mat HSV;
        Mat imgThresholded;
        cvtColor(frame, HSV, COLOR_BGR2HSV); //Convert the captured frame from BGR to HSV
        inRange(HSV, Scalar(iLowH, iLowS, iLowV), Scalar(iHighH, iHighS, iHighV), imgThresholded); //Threshold the image
        imshow("Webcam", frame);
        imshow("Threshold", imgThresholded);
     //  imshow("Threshold", imgThresholded);
        key = waitKey(30);
        if (key == 27) { //escape key pressed: stop program
            cout << "ESC pressed. Program closing..." << endl;
            break;
        }
        else if (key == ' ') { //spacebar pressed: take a picture
            imgOriginal = frame;
            Mat imgHSV;
          
            cvtColor(imgOriginal, imgHSV, COLOR_BGR2HSV); //Convert the captured frame from BGR to HSV
         //   imshow("HSV",imgHSV);
            Mat imgThresholded1;
            Mat imgThresholded2;
            Mat imgThresholded3;
            Mat imgThresholded4;

            inRange(imgHSV, Scalar(iLowH_R, iLowS_R, iLowV_R), Scalar(iHighH_R, iHighS_R, iHighV_R), imgThresholded1); //Threshold the image
            inRange(imgHSV, Scalar(iLowH_R, iLowS_R, iLowV_R), Scalar(iHighH_R, iHighS_R, iHighV_R), imgThresholded1); //Threshold the image
            inRange(imgHSV, Scalar(iLowH_O, iLowS_O, iLowV_O), Scalar(iHighH_O, iHighS_O, iHighV_O), imgThresholded2); //Threshold the image
            inRange(imgHSV, Scalar(iLowH_G, iLowS_G, iLowV_G), Scalar(iHighH_G, iHighS_G, iHighV_G), imgThresholded3); //Threshold the image
            inRange(imgHSV, Scalar(iLowH_Y, iLowS_Y, iLowV_Y), Scalar(iHighH_Y, iHighS_Y, iHighV_Y), imgThresholded4); //Threshold the image
           // imshow("In Range", imgThresholded1); //show the thresholded image
            Scalar colors1 = Scalar(220, 240, 60);
            Scalar colors2 = Scalar(220, 240, 120);
            string name_red = "RED";
          // Bộ lọc trung vị lọc cái nhiễu nhỏ và trung bình
            //imshow("blur", imgThresholded1); //show the thresholded image
            FilteredObject(imgThresholded1, imgOriginal, colors1, name_red);
            CircleObject(imgThresholded1, imgOriginal, colors2);
            imshow("Thresholded Image1", imgThresholded1); //show the thresholded image

            string name_orange = "ORANGE";
            
            FilteredObject(imgThresholded2, imgOriginal, colors1, name_orange);
            CircleObject(imgThresholded2, imgOriginal, colors2);
            // imshow("Thresholded Image2", imgThresholded2); //show the thresholded image

            string name_green = "GREEN";
           
           FilteredObject(imgThresholded3, imgOriginal, colors1, name_green);
            CircleObject(imgThresholded3, imgOriginal, colors2);
            // imshow("Thresholded Image 3", imgThresholded3); //show the thresholded image

            string name_yellow = "YELLOW";
           FilteredObject(imgThresholded4, imgOriginal, colors1, name_yellow);
            CircleObject(imgThresholded4, imgOriginal, colors2);
            // imshow("Thresholded Image 4", imgThresholded4); //show the thresholded image


            while (true) {
                imshow("imgOriginal", imgOriginal);

                key = waitKey(30);

                if (key == 27 || key == 32) {
                    cout << "ESC or SPACE pressed. Returning to video..." << endl;
                    destroyWindow("imgOriginal");
                    break;
                }


                if (key == 115) {

                    //trying to save to current directory
                    imageWrite(imgOriginal, to_string(dem));
                    // maybe bool is always getting value of 0, or false
                    cout << "s was pressed. saving image " << dem << endl;
                    for (int i = 0; i < 1; i++) { dem++; }
                }

            }

        }
    }

    return 0;
}