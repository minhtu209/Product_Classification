﻿#pragma once
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <stdio.h>
#include <conio.h>
namespace  {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO::Ports;

	cv::VideoCapture cap;
	cv::Mat frame;
	int a = 0;
	int dem = 0;
	const int FRAME_WIDTH = 300;
	const int FRAME_HEIGHT = 280;

	std::vector<int> scalar_red = { 160,150,60,179,255,255 };//GAM MÀU HSV CỦA MÀU ĐỎ
	std::vector<int> scalar_orange = { 0,150,60,22,255,255 };//GAM MÀU HSV CỦA MÀU CAM
	std::vector<int> scalar_green = { 75,150,60,130,255,255 };//GAM MÀU HSV CỦA MÀU XANH
	std::vector<int> scalar_other = {0,0,0,0,0,0};
	cv::Mat imgOriginal;
	cv::Mat imgHSV;
	char key;
	cv::Mat imgThresholded1;
	cv::Mat imgThresholded2;
	cv::Mat imgThresholded3;
	cv::Mat imgThresholded4;

	int count_red = 0;
	int count_orange = 0;
	int count_green = 0;
	int count_yellow = 0;

	bool prev = false;
	bool dem2 = false;
	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	private:
		Form^ obj;
		String^ message;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::GroupBox^ groupBox2;
	private: System::Windows::Forms::Button^ button_other;
	private: System::Windows::Forms::Button^ button_green;
	private: System::Windows::Forms::Button^ button_orange;
	private: System::Windows::Forms::Button^ button_red;
	private: System::Windows::Forms::GroupBox^ groupBox3;
	private: System::Windows::Forms::Label^ label15;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::TrackBar^ trackBar1;
	private: System::Windows::Forms::Label^ label_control;
	private: System::Windows::Forms::Label^ label3;
	private: System::IO::Ports::SerialPort^ serialPort2;
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		//khai báo một Delegate có nhiệm vụ nhận vào một tham số và đóng gói(không trả giá trị ra)-> truyền vào làm tham số cho hàm
		delegate void SetLabelTextDelegate(String^ text, Label^ label);
		//Tạo một hàm để lấy tham số của Delegate
		void SetLabelText(String^ text, Label^ label) {
			if (label->InvokeRequired)//InvokeRequired yêu cầu so sánh ID thread giữa text và label , nếu khác nhau thì trả về giá trị 1 
			{
				SetLabelTextDelegate^ d = gcnew SetLabelTextDelegate(this, &MyForm::SetLabelText); //Tạo con trỏ tới hàm SetLabelText
				this->Invoke(d, gcnew array<Object^>{text, label});//Thực hiện hàm SetLabelText lấy dữ liệu từ text->label
			}
			else {
				label->Text = text;
			}
		}

		MyForm(Form^ obj1,String^message1,std::vector<int>scalar_other1)
		{
			InitializeComponent();
			//Truyền các biến cần sử dụng từ Form1->MyForm
			obj = obj1;//truyền form obj->obj1
			message = message1;//truyền biến message1->message
			scalar_other = scalar_other1;//truyền biến scala_other1->scala_other
			SetLabelText(message,label_other);//truyền biến message->label->other
			// Set up các dữ liệu kết nối với Adruino
			array<Object^>^ objectArray = SerialPort::GetPortNames();//Set up cổng com
			this->comboBox1->Items->AddRange(objectArray);
			array<String^>^ baud = { "9600", "19200", "38400", "57600","78400", "115200" };//Set up baud rate
			this->comboBox2->Items->AddRange(baud);
			//
			//TODO: Add the constructor code here
			//
		}
	    
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label4;
	protected:
	private: System::Windows::Forms::Button^ button_save;
	private: System::Windows::Forms::Button^ button_stop;
	private: System::Windows::Forms::Button^ btnProcess;
	private: System::Windows::Forms::Button^ button_video;
	private: System::Windows::Forms::PictureBox^ picture;


	private: System::Windows::Forms::PictureBox^ Video;
	private: System::Windows::Forms::Label^ label_other;
	private: System::Windows::Forms::Label^ label_green;
	private: System::Windows::Forms::Label^ label_orange;
	private: System::Windows::Forms::Label^ label_red;
	private: System::Windows::Forms::Label^ labelcount_other;
	private: System::Windows::Forms::Label^ labelcount_green;
	private: System::Windows::Forms::Label^ labelcount_orange;
	private: System::Windows::Forms::Label^ labelcount_red;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label_exit;
	private: System::Windows::Forms::Button^ button_exit;
	private: System::Windows::Forms::TextBox^ textBox_next;
	private: System::Windows::Forms::Button^ button_next;


	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ button_disconnect;
	private: System::Windows::Forms::Button^ button_connect;
	private: System::Windows::Forms::ComboBox^ comboBox2;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::TextBox^ textBox_Connect;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button_save = (gcnew System::Windows::Forms::Button());
			this->button_stop = (gcnew System::Windows::Forms::Button());
			this->btnProcess = (gcnew System::Windows::Forms::Button());
			this->button_video = (gcnew System::Windows::Forms::Button());
			this->picture = (gcnew System::Windows::Forms::PictureBox());
			this->Video = (gcnew System::Windows::Forms::PictureBox());
			this->label_other = (gcnew System::Windows::Forms::Label());
			this->label_green = (gcnew System::Windows::Forms::Label());
			this->label_orange = (gcnew System::Windows::Forms::Label());
			this->label_red = (gcnew System::Windows::Forms::Label());
			this->labelcount_other = (gcnew System::Windows::Forms::Label());
			this->labelcount_green = (gcnew System::Windows::Forms::Label());
			this->labelcount_orange = (gcnew System::Windows::Forms::Label());
			this->labelcount_red = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label_exit = (gcnew System::Windows::Forms::Label());
			this->button_exit = (gcnew System::Windows::Forms::Button());
			this->textBox_next = (gcnew System::Windows::Forms::TextBox());
			this->button_next = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button_disconnect = (gcnew System::Windows::Forms::Button());
			this->button_connect = (gcnew System::Windows::Forms::Button());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->textBox_Connect = (gcnew System::Windows::Forms::TextBox());
			this->serialPort2 = (gcnew System::IO::Ports::SerialPort(this->components));
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->button_other = (gcnew System::Windows::Forms::Button());
			this->button_green = (gcnew System::Windows::Forms::Button());
			this->button_orange = (gcnew System::Windows::Forms::Button());
			this->button_red = (gcnew System::Windows::Forms::Button());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->trackBar1 = (gcnew System::Windows::Forms::TrackBar());
			this->label_control = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar1))->BeginInit();
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(98, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(155, 30);
			this->label4->TabIndex = 150;
			this->label4->Text = L"ĐẾM SỐ LƯỢNG";
			// 
			// button_save
			// 
			this->button_save->Location = System::Drawing::Point(366, 119);
			this->button_save->Name = L"button_save";
			this->button_save->Size = System::Drawing::Size(84, 23);
			this->button_save->TabIndex = 149;
			this->button_save->Text = L"Reset";
			this->button_save->UseVisualStyleBackColor = true;
			this->button_save->Click += gcnew System::EventHandler(this, &MyForm::button_save_Click);
			// 
			// button_stop
			// 
			this->button_stop->Location = System::Drawing::Point(269, 120);
			this->button_stop->Name = L"button_stop";
			this->button_stop->Size = System::Drawing::Size(75, 23);
			this->button_stop->TabIndex = 148;
			this->button_stop->Text = L"Stop";
			this->button_stop->UseVisualStyleBackColor = true;
			this->button_stop->Click += gcnew System::EventHandler(this, &MyForm::button_stop_Click);
			// 
			// btnProcess
			// 
			this->btnProcess->Location = System::Drawing::Point(366, 89);
			this->btnProcess->Name = L"btnProcess";
			this->btnProcess->Size = System::Drawing::Size(85, 23);
			this->btnProcess->TabIndex = 147;
			this->btnProcess->Text = L"Cap picture";
			this->btnProcess->UseVisualStyleBackColor = true;
			this->btnProcess->Click += gcnew System::EventHandler(this, &MyForm::btnProcess_Click);
			// 
			// button_video
			// 
			this->button_video->Location = System::Drawing::Point(269, 89);
			this->button_video->Name = L"button_video";
			this->button_video->Size = System::Drawing::Size(75, 23);
			this->button_video->TabIndex = 146;
			this->button_video->Text = L"Video";
			this->button_video->UseVisualStyleBackColor = true;
			this->button_video->Click += gcnew System::EventHandler(this, &MyForm::button_video_Click);
			// 
			// picture
			// 
			this->picture->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->picture->Location = System::Drawing::Point(588, 163);
			this->picture->Name = L"picture";
			this->picture->Size = System::Drawing::Size(311, 307);
			this->picture->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->picture->TabIndex = 145;
			this->picture->TabStop = false;
			// 
			// Video
			// 
			this->Video->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->Video->Location = System::Drawing::Point(269, 163);
			this->Video->Name = L"Video";
			this->Video->Size = System::Drawing::Size(313, 307);
			this->Video->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->Video->TabIndex = 144;
			this->Video->TabStop = false;
			// 
			// label_other
			// 
			this->label_other->BackColor = System::Drawing::Color::Lime;
			this->label_other->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_other->Location = System::Drawing::Point(219, 93);
			this->label_other->Name = L"label_other";
			this->label_other->Size = System::Drawing::Size(80, 20);
			this->label_other->TabIndex = 143;
			this->label_other->Text = L"  OTHER";
			this->label_other->Click += gcnew System::EventHandler(this, &MyForm::label_other_Click);
			// 
			// label_green
			// 
			this->label_green->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label_green->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_green->Location = System::Drawing::Point(219, 46);
			this->label_green->Name = L"label_green";
			this->label_green->Size = System::Drawing::Size(80, 20);
			this->label_green->TabIndex = 142;
			this->label_green->Text = L"BLUE";
			this->label_green->Click += gcnew System::EventHandler(this, &MyForm::label_green_Click);
			// 
			// label_orange
			// 
			this->label_orange->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label_orange->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_orange->Location = System::Drawing::Point(47, 95);
			this->label_orange->Name = L"label_orange";
			this->label_orange->Size = System::Drawing::Size(79, 20);
			this->label_orange->TabIndex = 141;
			this->label_orange->Text = L"ORANGE";
			// 
			// label_red
			// 
			this->label_red->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label_red->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_red->Location = System::Drawing::Point(47, 43);
			this->label_red->Name = L"label_red";
			this->label_red->Size = System::Drawing::Size(79, 24);
			this->label_red->TabIndex = 140;
			this->label_red->Text = L"    RED";
			// 
			// labelcount_other
			// 
			this->labelcount_other->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->labelcount_other->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelcount_other->Location = System::Drawing::Point(184, 93);
			this->labelcount_other->Name = L"labelcount_other";
			this->labelcount_other->Size = System::Drawing::Size(40, 20);
			this->labelcount_other->TabIndex = 139;
			this->labelcount_other->Text = L"0";
			this->labelcount_other->Click += gcnew System::EventHandler(this, &MyForm::labelcount_other_Click);
			// 
			// labelcount_green
			// 
			this->labelcount_green->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->labelcount_green->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelcount_green->Location = System::Drawing::Point(184, 46);
			this->labelcount_green->Name = L"labelcount_green";
			this->labelcount_green->Size = System::Drawing::Size(40, 20);
			this->labelcount_green->TabIndex = 138;
			this->labelcount_green->Text = L"0";
			// 
			// labelcount_orange
			// 
			this->labelcount_orange->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->labelcount_orange->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelcount_orange->Location = System::Drawing::Point(10, 95);
			this->labelcount_orange->Name = L"labelcount_orange";
			this->labelcount_orange->Size = System::Drawing::Size(40, 20);
			this->labelcount_orange->TabIndex = 137;
			this->labelcount_orange->Text = L"0";
			// 
			// labelcount_red
			// 
			this->labelcount_red->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->labelcount_red->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelcount_red->Location = System::Drawing::Point(10, 44);
			this->labelcount_red->Name = L"labelcount_red";
			this->labelcount_red->Size = System::Drawing::Size(40, 20);
			this->labelcount_red->TabIndex = 136;
			this->labelcount_red->Text = L"0";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(768, 99);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 31);
			this->button4->TabIndex = 135;
			this->button4->Text = L"ON";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 17, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(476, 99);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(286, 29);
			this->label2->TabIndex = 134;
			this->label2->Text = L"Cam bien chua hoat dong";
			// 
			// label_exit
			// 
			this->label_exit->AutoSize = true;
			this->label_exit->BackColor = System::Drawing::SystemColors::InactiveCaption;
			this->label_exit->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_exit->Location = System::Drawing::Point(83, 397);
			this->label_exit->Name = L"label_exit";
			this->label_exit->Size = System::Drawing::Size(56, 17);
			this->label_exit->TabIndex = 133;
			this->label_exit->Text = L"THOÁT";
			// 
			// button_exit
			// 
			this->button_exit->Location = System::Drawing::Point(38, 417);
			this->button_exit->Name = L"button_exit";
			this->button_exit->Size = System::Drawing::Size(147, 53);
			this->button_exit->TabIndex = 132;
			this->button_exit->Text = L"Exit";
			this->button_exit->UseVisualStyleBackColor = true;
			this->button_exit->Click += gcnew System::EventHandler(this, &MyForm::button_exit_Click);
			// 
			// textBox_next
			// 
			this->textBox_next->BackColor = System::Drawing::SystemColors::InactiveCaption;
			this->textBox_next->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox_next->Location = System::Drawing::Point(29, 273);
			this->textBox_next->Name = L"textBox_next";
			this->textBox_next->Size = System::Drawing::Size(165, 26);
			this->textBox_next->TabIndex = 131;
			this->textBox_next->Text = L"Về giao diện ban đầu";
			// 
			// button_next
			// 
			this->button_next->Location = System::Drawing::Point(38, 305);
			this->button_next->Name = L"button_next";
			this->button_next->Size = System::Drawing::Size(145, 54);
			this->button_next->TabIndex = 130;
			this->button_next->Text = L"Back";
			this->button_next->UseVisualStyleBackColor = true;
			this->button_next->Click += gcnew System::EventHandler(this, &MyForm::button_next_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->BackColor = System::Drawing::SystemColors::Control;
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->button_disconnect);
			this->groupBox1->Controls->Add(this->button_connect);
			this->groupBox1->Controls->Add(this->comboBox2);
			this->groupBox1->Controls->Add(this->comboBox1);
			this->groupBox1->Controls->Add(this->textBox_Connect);
			this->groupBox1->ForeColor = System::Drawing::SystemColors::ActiveCaption;
			this->groupBox1->Location = System::Drawing::Point(7, 34);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(247, 209);
			this->groupBox1->TabIndex = 127;
			this->groupBox1->TabStop = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 25, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(6, 144);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(224, 39);
			this->label1->TabIndex = 5;
			this->label1->Text = L"Disconnected";
			// 
			// button_disconnect
			// 
			this->button_disconnect->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->button_disconnect->Location = System::Drawing::Point(154, 94);
			this->button_disconnect->Name = L"button_disconnect";
			this->button_disconnect->Size = System::Drawing::Size(75, 23);
			this->button_disconnect->TabIndex = 4;
			this->button_disconnect->Text = L"Disconnect";
			this->button_disconnect->UseVisualStyleBackColor = true;
			this->button_disconnect->Click += gcnew System::EventHandler(this, &MyForm::button_disconnect_Click);
			// 
			// button_connect
			// 
			this->button_connect->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->button_connect->Location = System::Drawing::Point(154, 42);
			this->button_connect->Name = L"button_connect";
			this->button_connect->Size = System::Drawing::Size(75, 23);
			this->button_connect->TabIndex = 3;
			this->button_connect->Text = L"Connect";
			this->button_connect->UseVisualStyleBackColor = true;
			this->button_connect->Click += gcnew System::EventHandler(this, &MyForm::button_connect_Click);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Location = System::Drawing::Point(11, 94);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(121, 21);
			this->comboBox2->TabIndex = 2;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox2_SelectedIndexChanged);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(11, 42);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 1;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox1_SelectedIndexChanged);
			// 
			// textBox_Connect
			// 
			this->textBox_Connect->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->textBox_Connect->Location = System::Drawing::Point(67, 0);
			this->textBox_Connect->Name = L"textBox_Connect";
			this->textBox_Connect->Size = System::Drawing::Size(100, 20);
			this->textBox_Connect->TabIndex = 0;
			this->textBox_Connect->Text = L"         KẾT NỐI";
			// 
			// serialPort2
			// 
			this->serialPort2->DataReceived += gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &MyForm::serialPort2_DataReceived);
			// 
			// textBox1
			// 
			this->textBox1->Enabled = false;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(219, 116);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(80, 26);
			this->textBox1->TabIndex = 151;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label_green);
			this->groupBox2->Controls->Add(this->textBox1);
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Controls->Add(this->labelcount_red);
			this->groupBox2->Controls->Add(this->labelcount_orange);
			this->groupBox2->Controls->Add(this->labelcount_green);
			this->groupBox2->Controls->Add(this->labelcount_other);
			this->groupBox2->Controls->Add(this->label_red);
			this->groupBox2->Controls->Add(this->label_orange);
			this->groupBox2->Controls->Add(this->label_other);
			this->groupBox2->Location = System::Drawing::Point(926, 34);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(310, 161);
			this->groupBox2->TabIndex = 152;
			this->groupBox2->TabStop = false;
			// 
			// button_other
			// 
			this->button_other->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button_other->Location = System::Drawing::Point(158, 181);
			this->button_other->Name = L"button_other";
			this->button_other->Size = System::Drawing::Size(126, 30);
			this->button_other->TabIndex = 170;
			this->button_other->Text = L"ON_SERVO_OTHER";
			this->button_other->UseVisualStyleBackColor = true;
			this->button_other->Click += gcnew System::EventHandler(this, &MyForm::button_other_Click);
			// 
			// button_green
			// 
			this->button_green->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button_green->Location = System::Drawing::Point(158, 122);
			this->button_green->Name = L"button_green";
			this->button_green->Size = System::Drawing::Size(126, 30);
			this->button_green->TabIndex = 169;
			this->button_green->Text = L"ON_SERVO_BLUE";
			this->button_green->UseVisualStyleBackColor = true;
			this->button_green->Click += gcnew System::EventHandler(this, &MyForm::button_green_Click);
			// 
			// button_orange
			// 
			this->button_orange->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button_orange->Location = System::Drawing::Point(14, 181);
			this->button_orange->Name = L"button_orange";
			this->button_orange->Size = System::Drawing::Size(126, 30);
			this->button_orange->TabIndex = 168;
			this->button_orange->Text = L"ON_SERVO_ORANGE";
			this->button_orange->UseVisualStyleBackColor = true;
			this->button_orange->Click += gcnew System::EventHandler(this, &MyForm::button_orange_Click);
			// 
			// button_red
			// 
			this->button_red->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button_red->Location = System::Drawing::Point(14, 122);
			this->button_red->Name = L"button_red";
			this->button_red->Size = System::Drawing::Size(126, 30);
			this->button_red->TabIndex = 167;
			this->button_red->Text = L"ON_SERVO_RED";
			this->button_red->UseVisualStyleBackColor = true;
			this->button_red->Click += gcnew System::EventHandler(this, &MyForm::button_red_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->label15);
			this->groupBox3->Controls->Add(this->label14);
			this->groupBox3->Controls->Add(this->label13);
			this->groupBox3->Controls->Add(this->trackBar1);
			this->groupBox3->Controls->Add(this->button_red);
			this->groupBox3->Controls->Add(this->button_other);
			this->groupBox3->Controls->Add(this->button_orange);
			this->groupBox3->Controls->Add(this->button_green);
			this->groupBox3->Location = System::Drawing::Point(926, 237);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(323, 243);
			this->groupBox3->TabIndex = 171;
			this->groupBox3->TabStop = false;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->Location = System::Drawing::Point(180, 76);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(43, 22);
			this->label15->TabIndex = 174;
			this->label15->Text = L"Mức";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->BackColor = System::Drawing::Color::Fuchsia;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(79, 67);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(29, 31);
			this->label14->TabIndex = 173;
			this->label14->Text = L"0";
			this->label14->Click += gcnew System::EventHandler(this, &MyForm::label14_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->Location = System::Drawing::Point(180, 19);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(121, 16);
			this->label13->TabIndex = 172;
			this->label13->Text = L"Điều khiển băng tải";
			// 
			// trackBar1
			// 
			this->trackBar1->Location = System::Drawing::Point(6, 19);
			this->trackBar1->Maximum = 5;
			this->trackBar1->Name = L"trackBar1";
			this->trackBar1->Size = System::Drawing::Size(175, 45);
			this->trackBar1->TabIndex = 171;
			this->trackBar1->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar1_Scroll);
			// 
			// label_control
			// 
			this->label_control->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->label_control->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label_control->Location = System::Drawing::Point(1001, 213);
			this->label_control->Name = L"label_control";
			this->label_control->Size = System::Drawing::Size(174, 30);
			this->label_control->TabIndex = 172;
			this->label_control->Text = L"CONTROL PANEL";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 30, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label3->Location = System::Drawing::Point(379, 12);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(454, 46);
			this->label3->TabIndex = 209;
			this->label3->Text = L"PHÂN LOẠI SẢN PHẨM";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1226, 524);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label_control);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->button_save);
			this->Controls->Add(this->button_stop);
			this->Controls->Add(this->btnProcess);
			this->Controls->Add(this->button_video);
			this->Controls->Add(this->picture);
			this->Controls->Add(this->Video);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label_exit);
			this->Controls->Add(this->button_exit);
			this->Controls->Add(this->textBox_next);
			this->Controls->Add(this->button_next);
			this->Controls->Add(this->groupBox1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		void FilteredObject(cv::Mat& threshold, cv::Mat& cameraFeed, cv::Scalar& colors, std::string& display) // tìm và vẽ viền
		{
			std::vector< std::vector<cv::Point> > contours;
			std::vector<cv::Vec4i> hierarchy;
			//tìm đường viền của hình ảnh được lọc bằng cách sử dụng hàm findContours
			findContours(threshold, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);
			//Tìm đối tượng được lọc
			bool objectFound = false;
			if (hierarchy.size() > 0) {
				int numObjects = hierarchy.size();
				//Nếu số lượng vật nhỏ hơn 1000
				if (numObjects < 1000) {
                //Tính các moment của hình ảnh được ngưỡng
						cv::Moments moment = moments(threshold);
						double dM01 = moment.m01;
						double dM10 = moment.m10;
						double dArea = moment.m00;

						if (dArea > 10000) {
							//Tính toán tọa độ vị trí vật
							int posX = dM10 / dArea; //x=m10/m00
							int posY = dM01 / dArea; //y=m01/m00
							drawContours(cameraFeed, contours, -1, colors, 1.8);//vẽ đường viền
							putText(cameraFeed, display, cv::Point(posX, posY + 20), 1, 1, cv::Scalar(0, 0, 0), 2);

						}
						else objectFound = false; // nếu diện tích <= 10000, coi là không có vật thể nào trong ảnh
				}
				// Nếu số vật lớn hơn 1000 
				else putText(cameraFeed, "TOO MUCH NOISE! ADJUST FILTER", cv::Point(0, 50), 1, 2, cv::Scalar(0, 0, 255), 2);//Hiển thị thông báo ra màn hình
			}
		}


		void CircleObject(cv::Mat& threshold, cv::Mat& cameraFeed, cv::Scalar& colors, int& count, String^& port)// tìm đường tròn
		{
			medianBlur(threshold, threshold, 3);//bộ lọc trung vị
			std::vector<cv::Vec3f> circles;
			HoughCircles(threshold, circles, cv::HOUGH_GRADIENT, 1.5, threshold.rows, 100, 50, 50, 300);  // Phát hiện đường tròn		
			//Ghi tọa độ , bán kính , ghi chú lên màn hình và truyền tín hiệu ->serialPort
			for (int i = 0; i < circles.size(); i++) {
				std::cout << "Ball position X = " << circles[i][0] << ",\tY = " << circles[i][1] << ",\tRadius = " << circles[i][2] << "\n";
				cv::circle(cameraFeed, cv::Point((int)circles[i][0], (int)circles[i][1]), 3, colors, cv::FILLED);
				cv::circle(cameraFeed, cv::Point((int)circles[i][0], (int)circles[i][1]), (int)circles[i][2], colors, 2);
				putText(cameraFeed, "Detection Circle", cv::Point(20, 20), 1, 1, colors, 2);
				putText(cameraFeed, "0" + std::to_string(i + 1) + "(" + std::to_string((int)circles[i][0]) + "," + std::to_string((int)circles[i][1]) + ")", cv::Point(circles[i][0] - 5, circles[i][1] - 20), 1, 1, colors, 2);
				putText(cameraFeed, "R=" + std::to_string((int)circles[i][2]), cv::Point(circles[i][0], circles[i][1] - 35), 1, 1, colors, 2);
				count++;
				if (this->serialPort2->IsOpen) {
					serialPort2->WriteLine(port);
				}
			}
		}
		void imageWrite(const cv::Mat& image, const std::string filename)
		{
			// Hỗ trợ lưu file dạng JPEG
			std::vector<int> compression_params;
			compression_params.push_back(cv::IMWRITE_JPEG_QUALITY);
			compression_params.push_back(100);//Set up gtri chat luong anh la 100

			// ghi vào đường dẫn được chỉ định
			std::string path = "F:\\final\\" + filename + ".jpg";
			cv::imwrite(path, image, compression_params);
		}
		//BUTTON BACK->trở về form1
	private: System::Void button_next_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();//Đóng MyForm
		obj->Show();//Mở Form1
	}
		   //BUTTON EXIT->đóng tất cả form
private: System::Void button_exit_Click(System::Object^ sender, System::EventArgs^ e) {
	Application::Exit();//Đóng tất cả form
}
	   //BUTTON CONNECT->kết nối serialPort
private: System::Void button_connect_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->button_connect->Text == "Connect") {
		this->serialPort2->PortName = this->comboBox1->Text;
		this->serialPort2->BaudRate = Int32::Parse(this->comboBox2->Text);
		this->serialPort2->Open();

		this->label1->Text = "Connected";

		this->label1->ForeColor = Color::Green;
	}
}
	   //BUTTON_DISCONNECT->ngắt kết nối serialPort
private: System::Void button_disconnect_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->button_disconnect->Text == "Disconnect") {

		this->serialPort2->Close();
		this->label1->Text = "Disconnected";

		this->label1->ForeColor = Color::OrangeRed;
	}
}
	 //BUTTON VIDEO->bật camera
private: System::Void button_video_Click(System::Object^ sender, System::EventArgs^ e) {
	cap.open(0); //capture the video from webcam"http://192.168.1.7:4747/video"
	if (!cap.isOpened())  // if not success, exit program
	{
		//cout << "Cannot open the web cam" << endl;
		MessageBox::Show("Fail to open video");
		_getch();
		return;
	}
	cap.set(cv::CAP_PROP_FRAME_WIDTH, FRAME_WIDTH);
	cap.set(cv::CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT);
	while (true)
	{

		cap.retrieve(frame);
		bool success = cap.read(frame);
		if (!success) {
			MessageBox::Show("Could not read from video file");
			return;
		}
		key = cv::waitKey(30);
		//Hiển thị hình ảnh video trong khung pictureBox có sẵn trong Form
		System::Drawing::Graphics^ graphics2 = Video->CreateGraphics();
		System::IntPtr ptr2(frame.ptr());
		System::Drawing::Bitmap^ b2 = gcnew System::Drawing::Bitmap(frame.cols,frame.rows, frame.step, System::Drawing::Imaging::PixelFormat::Format24bppRgb, ptr2);
		System::Drawing::RectangleF rect2(0, 0, Video->Width, Video->Height);
		graphics2->DrawImage(b2, rect2);
		//Khi serialPort được kết nối -> Chế độ tự động
		if (this->serialPort2->IsOpen)  {
			//Nếu tín hiệu từ cảm biến qua cổng serial hiện tại nhận được bằng 0 và tín hiệu trước đó bằng 1
			if (a == 0 && prev == true) {
				btnProcess_Click(sender, e);//gọi hàm xử lý ảnh
				btnProcess->Enabled = false;//Khóa button Capture->chế độ tự động xử lý
				prev = false;//lưu giá trị biến trước đó =0
			}
			//Nếu giá trị a=prev=0 
			else if (a == 0 && prev == false) { continue;}//bỏ qua ->tiếp tục thực hiện lệnh sau đó 
			//Nếu a=1
			else if (a == 1) {
				//Không chụp ảnh và hiển thị ảnh khung pictureBox 2
				picture->Image = nullptr;
				btnProcess->Enabled = false;
				prev = true;//Lưu giá trị prev=1
			}
		}
		else { btnProcess->Enabled = true; }//Nếu không kết nối serialPort->chế độ điều khiển
	}
}
	   //BUTTON Capture->Chụp và xử lý ảnh từ Camera
private: System::Void btnProcess_Click(System::Object^ sender, System::EventArgs^ e) {
	imgOriginal = frame;//gán hình ảnh từ camera->biến imgOriginal
	cv::Mat imgHSV;
	cvtColor(imgOriginal, imgHSV, cv::COLOR_BGR2HSV); //chuyển BGR -> HSV
	//Ngưỡng hình ảnh->Ảnh xám cho các màu đỏ , cam ,xanh và 1 màu được truyền từ Form1
	inRange(imgHSV, cv::Scalar(scalar_red[0], scalar_red[1], scalar_red[2]), cv::Scalar(scalar_red[3], scalar_red[4], scalar_red[5]), imgThresholded1); 
	inRange(imgHSV, cv::Scalar(scalar_orange[0], scalar_orange[1], scalar_orange[2]), cv::Scalar(scalar_orange[3], scalar_orange[4], scalar_orange[5]), imgThresholded2); 
	inRange(imgHSV, cv::Scalar(scalar_green[0], scalar_green[1], scalar_green[2]), cv::Scalar(scalar_green[3], scalar_green[4], scalar_green[5]), imgThresholded3); 
	inRange(imgHSV, cv::Scalar(scalar_other[0], scalar_other[1], scalar_other[2]), cv::Scalar(scalar_other[3], scalar_other[4], scalar_other[5]), imgThresholded4); 

	cv::Scalar colors1 = cv::Scalar(220, 240, 60);
	cv::Scalar colors2 = cv::Scalar(220, 240, 120);
	//Màu đỏ
	std::string name_red = "RED";
	String^ port_red = "r";
	blur(imgThresholded1, imgThresholded1, cv::Size(3, 3));
	FilteredObject(imgThresholded1, imgOriginal, colors1, name_red);
	CircleObject(imgThresholded1, imgOriginal, colors2, count_red, port_red);
	labelcount_red->Text = "" + count_red;
	//Màu cam
	std::string name_orange = "ORANGE";
	String^ port_orange = "o";
	blur(imgThresholded2, imgThresholded2, cv::Size(5, 5));
	FilteredObject(imgThresholded2, imgOriginal, colors1, name_orange);
	CircleObject(imgThresholded2, imgOriginal, colors2, count_orange, port_orange);
	labelcount_orange->Text = "" + count_orange;
	//Màu xanh
	std::string name_green = "BLUE";
	String^ port_green = "g";
	blur(imgThresholded3, imgThresholded3, cv::Size(5, 5));
	FilteredObject(imgThresholded3, imgOriginal, colors1, name_green);
	CircleObject(imgThresholded3, imgOriginal, colors2, count_green, port_green);
	labelcount_green->Text = "" + count_green;
	//Màu nhận được ở Form1
	std::string name_yellow = "OTHER";
	String^ port_yellow = "y";
	blur(imgThresholded4, imgThresholded4, cv::Size(5, 5));
	FilteredObject(imgThresholded4, imgOriginal, colors1, name_yellow);
	CircleObject(imgThresholded4, imgOriginal, colors2, count_yellow, port_yellow);
	labelcount_other->Text = "" + count_yellow;
	
	//Hiển thị ảnh trong khung pictureBox trong MyForm
	System::Drawing::Graphics^ graphics = picture->CreateGraphics();
	System::IntPtr ptr(imgOriginal.ptr());
	System::Drawing::Bitmap^ b = gcnew System::Drawing::Bitmap(imgOriginal.cols,imgOriginal.rows, imgOriginal.step, System::Drawing::Imaging::PixelFormat::Format24bppRgb, ptr);
	System::Drawing::RectangleF rect(0, 0, picture->Width, picture->Height);
	graphics->DrawImage(b, rect);

	//Lưu hình ảnh vào đường dẫn chỉ định , địa chỉ là số nguyên tăng dần -> Không trùng địa chỉ
	imageWrite(imgOriginal, std::to_string(dem));
	for (int i = 0; i < 1; i++) { dem++; }
}
	   //BUTTON STOP -> Dừng quay video
private: System::Void button_stop_Click(System::Object^ sender, System::EventArgs^ e) {
	Video->Image = nullptr;//Không hiển thị Video trên pictureBox1
	picture->Image = nullptr;//Không hiển thị ảnh trên pictureBox2
	cap.release(); //Tắt webcam
}
	   //BUTTON RESET->Đưa các giá trị đếm số lượng về 0
private: System::Void button_save_Click(System::Object^ sender, System::EventArgs^ e) {
	labelcount_red->Text = "0";
	labelcount_orange->Text = "0";
	labelcount_green->Text = "0";
	labelcount_other->Text = "0";
	count_red = 0;
	count_orange = 0;
	count_green = 0;
	count_yellow = 0;
}
	 //Bật/Tắt cảm biến
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->serialPort2->IsOpen)
	{
		if (this->button4->Text == "ON")
		{
			this->serialPort2->WriteLine("a");
			this->button4->Text = "OFF";
			dem2 = true;
		}
		else
		{
			this->serialPort2->WriteLine("b");
			this->button4->Text = "ON";
			this->label2->Text = "Cam bien chua hoat dong";
			dem2 = false;
		}
	}
	else
	{
		MessageBox::Show("Port Not Opened");
	}
}
	   
	   String^ canhbao; //Khai báo tín hiệu nhận được từ cảm biến truyền lên serialPort
	   //Hàm đọc dữ liệu serialPort2 nhận được
private: System::Void serialPort2_DataReceived(System::Object^ sender, System::IO::Ports::SerialDataReceivedEventArgs^ e) {
	if (this->serialPort2->IsOpen) {
		if (dem2) {
			SetLabelText(String::Empty, label2);//Thời gian chưa nhận dữ liệu->label2 hiển thị ""
			try
			{
				canhbao = serialPort2->ReadLine();
				if (Int32::Parse(canhbao) == 0)//Nếu tín hiệu nhận được =0
				{
					a = 0;//gán biến trung gian a=0
					SetLabelText("Phat hien co vat", label2);//Hiển thị label2->Phát hiện có vật
				}
				else {
					a = 1;//Ngược lại gán a=1
					SetLabelText("Chua co vat", label2);////Hiển thị label2->Chưa có vật
				}

			}
			catch (TimeoutException^) {
				SetLabelText("Cam bien chua hoat dong", label2);//Thời gian chưa bật cảm biến->label2 hiển thị "Cảm biến chưa hoạt động"
			}
		}

		else
		{
			SetLabelText("Cam bien chua hoat dong", label2);//Chưa kết nối cổng com->label2 hiển thị "Cảm biến chưa hoạt động"

		}
	}
}
private: System::Void label_other_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
	   //BẬT/TẮT SERVO GẠT VẬT MÀU ĐỎ ->KHAY1
private: System::Void button_red_Click(System::Object^ sender, System::EventArgs^ e) {
	if (serialPort2->IsOpen)
	{

		if (this->button_red->Text == "ON_SERVO_RED")
		{
			this->serialPort2->WriteLine("1");

			this->button_red->Text = "OFF_SERVO_RED";
		}
		else
		{
			this->serialPort2->WriteLine("0");

			this->button_red->Text = "ON_SERVO_RED";
		}
	}
	else
	{
		MessageBox::Show("Port Not Opened");
	}
}
	   //BẬT/TẮT SERVO GẠT VẬT MÀU XANH ->KHAY2
private: System::Void button_green_Click(System::Object^ sender, System::EventArgs^ e) {
	if (serialPort2->IsOpen)
	{

		if (this->button_green->Text == "ON_SERVO_BLUE")
		{
			this->serialPort2->WriteLine("3");

			this->button_green->Text = "OFF_SERVO_BLUE";
		}
		else
		{
			this->serialPort2->WriteLine("2");

			this->button_green->Text = "ON_SERVO_BLUE";
		}
	}
	else
	{
		MessageBox::Show("Port Not Opened");
	}
}
	   //BẬT/TẮT SERVO GẠT VẬT MÀU CAM ->KHAY3
private: System::Void button_orange_Click(System::Object^ sender, System::EventArgs^ e) {
	if (serialPort2->IsOpen)
	{

		if (this->button_orange->Text == "ON_SERVO_ORANGE")
		{
			this->serialPort2->WriteLine("5");

			this->button_orange->Text = "OFF_SERVO_ORANGE";
		}
		else
		{
			this->serialPort2->WriteLine("4");

			this->button_orange->Text = "ON_SERVO_ORANGE";
		}
	}
	else
	{
		MessageBox::Show("Port Not Opened");
	}
}
	   //BẬT/TẮT SERVO GẠT VẬT KHÁC ->KHAY4
private: System::Void button_other_Click(System::Object^ sender, System::EventArgs^ e) {
	if (serialPort2->IsOpen)
	{

		if (this->button_other->Text == "ON_SERVO_OTHER")
		{
			this->serialPort2->WriteLine("7");

			this->button_other->Text = "OFF_SERVO_OTHER";
		}
		else
		{
			this->serialPort2->WriteLine("6");

			this->button_other->Text = "ON_SERVO_OTHER";
		}
	}
	else
	{
		MessageBox::Show("Port Not Opened");
	}
}
	   //TRASKBAR ĐIỀU KHIỂN TỐC ĐỘ ĐỘNG CƠ BĂNG TẢI
private: System::Void trackBar1_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label14->Text = this->trackBar1->Value.ToString();//HIỂN THỊ CÁC MỨC TỐC ĐỘ TRÊN LABEL14
	if (this->serialPort2->IsOpen)
	{

		switch (this->trackBar1->Value)
		{
		case 0:
		{
			serialPort2->WriteLine("l");

			break;
		}
		case 1:
		{
			serialPort2->WriteLine("m");

			break;
		}
		case 2:
		{
			serialPort2->WriteLine("n");

			break;
		}
		case 3:
		{
			serialPort2->WriteLine("i");

			break;
		}
		case 4:
		{
			serialPort2->WriteLine("j");

			break;
		}
		case 5:
		{
			serialPort2->WriteLine("k");

			break;
		}

		default:
		{

			break;
		}
		}


	}
	else { MessageBox::Show("Port Not Opened"); }
}
private: System::Void label14_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void labelcount_other_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label_green_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void comboBox2_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
}
};
}
