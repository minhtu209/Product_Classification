﻿#pragma once
#include "MyForm.h"
namespace CppCLRWinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO::Ports;
	cv::VideoCapture cap;
	cv::Mat frame;
	cv::Mat imgThresholded;
	char key;
	int iLowH = 0;
	int iHighH = 0;

	int iLowS = 0;
	int iHighS = 0;

	int iLowV = 0;
	int iHighV = 0;
	int FRAME_WIDTH = 300;
	int FRAME_HEIGHT = 280;
	/// <summary>
	/// Zusammenfassung für Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzufügen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button_save;
	protected:
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::PictureBox^ Video_gray;
	private: System::Windows::Forms::Button^ button_stop;
	private: System::Windows::Forms::Button^ button_transform;
	private: System::Windows::Forms::Label^ label_Smin;
	private: System::Windows::Forms::Label^ label_Smax;
	private: System::Windows::Forms::Label^ label_Vmin;
	private: System::Windows::Forms::Label^ label_Vmax;
	private: System::Windows::Forms::Label^ label_Hmin;
	private: System::Windows::Forms::Label^ label_Hmax;
	private: System::Windows::Forms::TrackBar^ trbSmax;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TrackBar^ trbSmin;
	private: System::Windows::Forms::TrackBar^ trbVmax;
	private: System::Windows::Forms::TrackBar^ trbVmin;
	private: System::Windows::Forms::TrackBar^ trbHmax;
	private: System::Windows::Forms::TrackBar^ trbHmin;
	private: System::Windows::Forms::PictureBox^ Video_color;
	private: System::Windows::Forms::Button^ button_test;
	private: System::Windows::Forms::Label^ label22;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::Button^ button_exit;
	private: System::Windows::Forms::Button^ button_back;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::Label^ label3;
		   //private: System::IO::Ports::SerialPort^ sp;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode für die Designerunterstützung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button_save = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->Video_gray = (gcnew System::Windows::Forms::PictureBox());
			this->button_stop = (gcnew System::Windows::Forms::Button());
			this->button_transform = (gcnew System::Windows::Forms::Button());
			this->label_Smin = (gcnew System::Windows::Forms::Label());
			this->label_Smax = (gcnew System::Windows::Forms::Label());
			this->label_Vmin = (gcnew System::Windows::Forms::Label());
			this->label_Vmax = (gcnew System::Windows::Forms::Label());
			this->label_Hmin = (gcnew System::Windows::Forms::Label());
			this->label_Hmax = (gcnew System::Windows::Forms::Label());
			this->trbSmax = (gcnew System::Windows::Forms::TrackBar());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->trbSmin = (gcnew System::Windows::Forms::TrackBar());
			this->trbVmax = (gcnew System::Windows::Forms::TrackBar());
			this->trbVmin = (gcnew System::Windows::Forms::TrackBar());
			this->trbHmax = (gcnew System::Windows::Forms::TrackBar());
			this->trbHmin = (gcnew System::Windows::Forms::TrackBar());
			this->Video_color = (gcnew System::Windows::Forms::PictureBox());
			this->button_test = (gcnew System::Windows::Forms::Button());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button_exit = (gcnew System::Windows::Forms::Button());
			this->button_back = (gcnew System::Windows::Forms::Button());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video_gray))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbSmax))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbSmin))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbVmax))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbVmin))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbHmax))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbHmin))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video_color))->BeginInit();
			this->SuspendLayout();
			// 
			// button_save
			// 
			this->button_save->Location = System::Drawing::Point(517, 140);
			this->button_save->Name = L"button_save";
			this->button_save->Size = System::Drawing::Size(75, 23);
			this->button_save->TabIndex = 207;
			this->button_save->Text = L"SAVE";
			this->button_save->UseVisualStyleBackColor = true;
			this->button_save->Click += gcnew System::EventHandler(this, &Form1::button_save_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(411, 143);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 206;
			// 
			// Video_gray
			// 
			this->Video_gray->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->Video_gray->Location = System::Drawing::Point(743, 173);
			this->Video_gray->Name = L"Video_gray";
			this->Video_gray->Size = System::Drawing::Size(344, 324);
			this->Video_gray->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->Video_gray->TabIndex = 196;
			this->Video_gray->TabStop = false;
			// 
			// button_stop
			// 
			this->button_stop->Location = System::Drawing::Point(248, 143);
			this->button_stop->Name = L"button_stop";
			this->button_stop->Size = System::Drawing::Size(75, 23);
			this->button_stop->TabIndex = 195;
			this->button_stop->Text = L"Stop";
			this->button_stop->UseVisualStyleBackColor = true;
			this->button_stop->Click += gcnew System::EventHandler(this, &Form1::button_stop_Click);
			// 
			// button_transform
			// 
			this->button_transform->Location = System::Drawing::Point(146, 143);
			this->button_transform->Name = L"button_transform";
			this->button_transform->Size = System::Drawing::Size(75, 23);
			this->button_transform->TabIndex = 194;
			this->button_transform->Text = L"Reset";
			this->button_transform->UseVisualStyleBackColor = true;
			this->button_transform->Click += gcnew System::EventHandler(this, &Form1::button_transform_Click);
			// 
			// label_Smin
			// 
			this->label_Smin->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Smin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Smin->Location = System::Drawing::Point(258, 411);
			this->label_Smin->Name = L"label_Smin";
			this->label_Smin->Size = System::Drawing::Size(86, 38);
			this->label_Smin->TabIndex = 193;
			this->label_Smin->Text = L"0";
			this->label_Smin->UseMnemonic = false;
			// 
			// label_Smax
			// 
			this->label_Smax->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Smax->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Smax->Location = System::Drawing::Point(258, 459);
			this->label_Smax->Name = L"label_Smax";
			this->label_Smax->Size = System::Drawing::Size(86, 38);
			this->label_Smax->TabIndex = 192;
			this->label_Smax->Text = L"0";
			this->label_Smax->UseMnemonic = false;
			// 
			// label_Vmin
			// 
			this->label_Vmin->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Vmin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Vmin->Location = System::Drawing::Point(258, 309);
			this->label_Vmin->Name = L"label_Vmin";
			this->label_Vmin->Size = System::Drawing::Size(86, 38);
			this->label_Vmin->TabIndex = 191;
			this->label_Vmin->Text = L"0";
			this->label_Vmin->UseMnemonic = false;
			// 
			// label_Vmax
			// 
			this->label_Vmax->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Vmax->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Vmax->Location = System::Drawing::Point(258, 360);
			this->label_Vmax->Name = L"label_Vmax";
			this->label_Vmax->Size = System::Drawing::Size(86, 38);
			this->label_Vmax->TabIndex = 190;
			this->label_Vmax->Text = L"0";
			this->label_Vmax->UseMnemonic = false;
			// 
			// label_Hmin
			// 
			this->label_Hmin->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Hmin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Hmin->Location = System::Drawing::Point(258, 207);
			this->label_Hmin->Name = L"label_Hmin";
			this->label_Hmin->Size = System::Drawing::Size(86, 38);
			this->label_Hmin->TabIndex = 189;
			this->label_Hmin->Text = L"0";
			this->label_Hmin->UseMnemonic = false;
			// 
			// label_Hmax
			// 
			this->label_Hmax->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->label_Hmax->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label_Hmax->Location = System::Drawing::Point(258, 258);
			this->label_Hmax->Name = L"label_Hmax";
			this->label_Hmax->Size = System::Drawing::Size(86, 38);
			this->label_Hmax->TabIndex = 188;
			this->label_Hmax->Text = L"0";
			this->label_Hmax->UseMnemonic = false;
			// 
			// trbSmax
			// 
			this->trbSmax->Location = System::Drawing::Point(66, 452);
			this->trbSmax->Maximum = 255;
			this->trbSmax->Name = L"trbSmax";
			this->trbSmax->Size = System::Drawing::Size(186, 45);
			this->trbSmax->TabIndex = 186;
			this->trbSmax->Scroll += gcnew System::EventHandler(this, &Form1::trbSmax_Scroll);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(24, 411);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(30, 13);
			this->label6->TabIndex = 187;
			this->label6->Text = L"Smin";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(23, 459);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(33, 13);
			this->label4->TabIndex = 185;
			this->label4->Text = L"Smax";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(27, 360);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(33, 13);
			this->label5->TabIndex = 184;
			this->label5->Text = L"Vmax";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(24, 309);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(30, 13);
			this->label7->TabIndex = 183;
			this->label7->Text = L"Vmin";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(24, 258);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(34, 13);
			this->label8->TabIndex = 182;
			this->label8->Text = L"Hmax";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(25, 207);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(31, 13);
			this->label9->TabIndex = 181;
			this->label9->Text = L"Hmin";
			// 
			// trbSmin
			// 
			this->trbSmin->Location = System::Drawing::Point(66, 411);
			this->trbSmin->Maximum = 255;
			this->trbSmin->Name = L"trbSmin";
			this->trbSmin->Size = System::Drawing::Size(186, 45);
			this->trbSmin->TabIndex = 180;
			this->trbSmin->Scroll += gcnew System::EventHandler(this, &Form1::trbSmin_Scroll);
			// 
			// trbVmax
			// 
			this->trbVmax->Location = System::Drawing::Point(66, 360);
			this->trbVmax->Maximum = 255;
			this->trbVmax->Name = L"trbVmax";
			this->trbVmax->Size = System::Drawing::Size(186, 45);
			this->trbVmax->TabIndex = 179;
			this->trbVmax->Scroll += gcnew System::EventHandler(this, &Form1::trbVmax_Scroll);
			// 
			// trbVmin
			// 
			this->trbVmin->Location = System::Drawing::Point(66, 309);
			this->trbVmin->Maximum = 255;
			this->trbVmin->Name = L"trbVmin";
			this->trbVmin->Size = System::Drawing::Size(186, 45);
			this->trbVmin->TabIndex = 178;
			this->trbVmin->Scroll += gcnew System::EventHandler(this, &Form1::trbVmin_Scroll);
			// 
			// trbHmax
			// 
			this->trbHmax->Location = System::Drawing::Point(66, 258);
			this->trbHmax->Maximum = 255;
			this->trbHmax->Name = L"trbHmax";
			this->trbHmax->Size = System::Drawing::Size(186, 45);
			this->trbHmax->TabIndex = 177;
			this->trbHmax->Scroll += gcnew System::EventHandler(this, &Form1::trbHmax_Scroll);
			// 
			// trbHmin
			// 
			this->trbHmin->Location = System::Drawing::Point(66, 207);
			this->trbHmin->Maximum = 255;
			this->trbHmin->Name = L"trbHmin";
			this->trbHmin->Size = System::Drawing::Size(186, 45);
			this->trbHmin->TabIndex = 176;
			this->trbHmin->Scroll += gcnew System::EventHandler(this, &Form1::trbHmin_Scroll);
			// 
			// Video_color
			// 
			this->Video_color->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->Video_color->Location = System::Drawing::Point(395, 173);
			this->Video_color->Name = L"Video_color";
			this->Video_color->Size = System::Drawing::Size(342, 324);
			this->Video_color->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->Video_color->TabIndex = 175;
			this->Video_color->TabStop = false;
			// 
			// button_test
			// 
			this->button_test->Location = System::Drawing::Point(40, 143);
			this->button_test->Name = L"button_test";
			this->button_test->Size = System::Drawing::Size(75, 23);
			this->button_test->TabIndex = 174;
			this->button_test->Text = L"Video";
			this->button_test->UseVisualStyleBackColor = true;
			this->button_test->Click += gcnew System::EventHandler(this, &Form1::button_test_Click);
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->BackColor = System::Drawing::Color::Yellow;
			this->label22->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label22->Location = System::Drawing::Point(1001, 20);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(50, 20);
			this->label22->TabIndex = 173;
			this->label22->Text = L"Thoát";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->BackColor = System::Drawing::Color::Yellow;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(12, 20);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(140, 20);
			this->label16->TabIndex = 172;
			this->label16->Text = L"Tới giao diện chính";
			// 
			// button_exit
			// 
			this->button_exit->Location = System::Drawing::Point(973, 61);
			this->button_exit->Name = L"button_exit";
			this->button_exit->Size = System::Drawing::Size(96, 54);
			this->button_exit->TabIndex = 171;
			this->button_exit->Text = L"Exit";
			this->button_exit->UseVisualStyleBackColor = true;
			this->button_exit->Click += gcnew System::EventHandler(this, &Form1::button_exit_Click);
			// 
			// button_back
			// 
			this->button_back->Location = System::Drawing::Point(16, 61);
			this->button_back->Name = L"button_back";
			this->button_back->Size = System::Drawing::Size(99, 54);
			this->button_back->TabIndex = 170;
			this->button_back->Text = L"NEXT";
			this->button_back->UseVisualStyleBackColor = true;
			this->button_back->Click += gcnew System::EventHandler(this, &Form1::button_back_Click);
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->dateTimePicker1->Location = System::Drawing::Point(743, 12);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(214, 26);
			this->dateTimePicker1->TabIndex = 209;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
			static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 30, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
			static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
			static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label3->Location = System::Drawing::Point(403, 20);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(281, 46);
			this->label3->TabIndex = 208;
			this->label3->Text = L"Color Tracking";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1108, 546);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->button_save);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->Video_gray);
			this->Controls->Add(this->button_stop);
			this->Controls->Add(this->button_transform);
			this->Controls->Add(this->label_Smin);
			this->Controls->Add(this->label_Smax);
			this->Controls->Add(this->label_Vmin);
			this->Controls->Add(this->label_Vmax);
			this->Controls->Add(this->label_Hmin);
			this->Controls->Add(this->label_Hmax);
			this->Controls->Add(this->trbSmax);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->trbSmin);
			this->Controls->Add(this->trbVmax);
			this->Controls->Add(this->trbVmin);
			this->Controls->Add(this->trbHmax);
			this->Controls->Add(this->trbHmin);
			this->Controls->Add(this->Video_color);
			this->Controls->Add(this->button_test);
			this->Controls->Add(this->label22);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->button_exit);
			this->Controls->Add(this->button_back);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video_gray))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbSmax))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbSmin))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbVmax))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbVmin))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbHmax))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trbHmin))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Video_color))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		
#pragma endregion
		// BUTTON EXIT-ĐÓNG TẤT CẢ FORM
	private: System::Void button_exit_Click(System::Object^ sender, System::EventArgs^ e) { 
		Application::Exit();//Thoát tất cả Form 
	}
		   //BUTTON NEXT-CHUYỂN SANG MYFORM
private: System::Void button_back_Click(System::Object^ sender, System::EventArgs^ e) {
	std::vector<int>color_HSV = { iLowH ,iLowS ,iLowV ,iHighH ,iHighS ,iHighV };//Tạo biến giá trị HSV của Fom1 để truyền vào My Form
	this->Hide();//Ẩn Form1 
	MyForm^ obj1 = gcnew MyForm(this,textBox1->Text,color_HSV);//tạo một MyForm mới tên obj1 , cấp phát bộ nhớ cho chúng và truyền các thông tin trong () từ Form1->MyForm  
	obj1->ShowDialog();//Hiển thi MyForm và ngưng thực hiện các câu lệnh trên Form1 cho đến khi Form được đóng lại
}
	   //BUTTON SAVE-LƯU TÊN VÀ GIÁ TRỊ HSV CỦA 1 MÀU MỚI ĐƯỢC PHÁT HIỆN
private: System::Void button_save_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->button_save->Text == "SAVE")  // Nhấn SAVE
	{
		this->button_save->Text = "UNSAVE";
		this->textBox1->Enabled = false; // Khóa textBox1 -> không cho phép chỉnh sửa
		//Lưu giá trị của các thanh traskbar HSV vào các biến iLow,iHigh phục vụ việc truyền dữ liệu giữa 2 Form
		iLowH = trbHmin->Value;    
		iLowS = trbSmin->Value;
		iLowV = trbVmin->Value;
		iHighH = trbHmax->Value;
		iHighS = trbSmax->Value;
		iHighV = trbVmax->Value;
	}
	else // Nhấn UNSAVE
	{
		this->button_save->Text = "SAVE"; 
		this->textBox1->Enabled = true; // Mở khóa textBox1 , cho phép chỉnh sửa

	}
}
	   //BUTTON_VIDEO
private: System::Void button_test_Click(System::Object^ sender, System::EventArgs^ e) {
	cap.open(0); //Mở Camera Webcam
	if (!cap.isOpened())  // if not success, exit program
	{
		MessageBox::Show("Fail to open video"); // Hiển thị thông báo không mở được Video
		_getch();
		return;
	}
	// Set up kích thước khung hình Camera
	cap.set(cv::CAP_PROP_FRAME_WIDTH, FRAME_WIDTH);
	cap.set(cv::CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT);
	while (true)
	{

		cap.retrieve(frame);//Giải mã và đưa thông tin Camera vào biến cv::Mat frame
		bool success = cap.read(frame); // Đọc dữ liệu từ frame
		if (!success) //Nếu không đọc được dữ liệu
		{
			MessageBox::Show("Could not read from video file"); //Hiển thị thông báo
			return;
		}
		key = cv::waitKey(30);
		//Đưa hình ảnh trong Camera vào PictureBox Video_color của Form
		System::Drawing::Graphics^ graphics2 = Video_color->CreateGraphics();// Tạo một đối tượng đồ họa cho PictureBox Video_color
		System::IntPtr ptr2(frame.ptr());// Tạo biến ptr2-đại diện cho con trỏ của frame (dành cho Winform)-> hàm Bitmap bên dưới
		System::Drawing::Bitmap^ b2 = gcnew System::Drawing::Bitmap(frame.cols,
			frame.rows, frame.step, System::Drawing::Imaging::PixelFormat::Format24bppRgb, ptr2); // Khởi tạo biến Bitmap bao gồm dữ liệu size,pixel cho hình ảnh đồ họa và các thuộc tính của nó phù hợp với Winform
		System::Drawing::RectangleF rect2(0, 0, Video_color->Width, Video_color->Height);// Tạo khung chữ nhật kích thước như pictureBox 
		graphics2->DrawImage(b2, rect2);//Vẽ hình ảnh ra màn hình trong khung chữ nhật size như rect2

		//Tạo biến HSV
		cv::Mat HSV;
		cvtColor(frame, HSV, cv::COLOR_BGR2HSV); //Chuyển ảnh dạng BGR -> HSV
		inRange(HSV, cv::Scalar(trbHmin->Value,trbSmin->Value, trbVmin->Value), cv::Scalar(trbHmax->Value, trbSmax->Value, trbVmax->Value), imgThresholded); //Ngưỡng hình ảnh->Ảnh xám
		
		//Đưa hình ảnh trong Camera vào PictureBox Video_gray của Form
		System::Drawing::Graphics^ graphics = Video_gray->CreateGraphics();
		System::IntPtr ptr(imgThresholded.ptr());
		System::Drawing::Bitmap^ b = gcnew System::Drawing::Bitmap(imgThresholded.cols,
			imgThresholded.rows, imgThresholded.step, System::Drawing::Imaging::PixelFormat::Format8bppIndexed, ptr);
		System::Drawing::RectangleF rect(0, 0, Video_gray->Width, Video_gray->Height);
		graphics->DrawImage(b, rect);

	}
}
	   //BUTTON RESET - đưa các giá trị traskbar HSV về 0
private: System::Void button_transform_Click(System::Object^ sender, System::EventArgs^ e) {
	trbHmin->Value = 0;
	trbSmin->Value = 0;
	trbVmin->Value = 0;
	trbHmax->Value = 0;
	trbSmax->Value = 0;
	trbVmax->Value = 0;

	this->label_Hmax->Text = "0";
	this->label_Hmin->Text = "0";
	this->label_Vmin->Text = "0";
	this->label_Vmax->Text = "0";
	this->label_Smax->Text = "0";
	this->label_Smin->Text = "0";
}
private: System::Void button_stop_Click(System::Object^ sender, System::EventArgs^ e) {
	Video_color->Image = nullptr;
	Video_gray->Image = nullptr;
	cap.release();
}
private: System::Void trbHmin_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Hmin->Text = this->trbHmin->Value.ToString();
}
private: System::Void trbHmax_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Hmax->Text = this->trbHmax->Value.ToString();
}
private: System::Void trbVmin_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Vmin->Text = this->trbVmin->Value.ToString();
}
private: System::Void trbVmax_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Vmax->Text = this->trbVmax->Value.ToString();
}
private: System::Void trbSmin_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Smin->Text = this->trbSmin->Value.ToString();
}
private: System::Void trbSmax_Scroll(System::Object^ sender, System::EventArgs^ e) {
	this->label_Smax->Text = this->trbSmax->Value.ToString();
}
};
}
